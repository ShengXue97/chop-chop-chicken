from cryptography.fernet import Fernet
message = "my deep dark secret".encode()
key = Fernet.generate_key()

f = Fernet(key)
# Encrypt the bytes. The returning object is of type bytes
encrypted = f.encrypt(message)
print(key)
print(encrypted)
