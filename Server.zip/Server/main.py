from flask import Flask
from datetime import datetime
from flask import request
import flask
import os
import uuid
from azure.storage.blob import BlobServiceClient, BlobClient, ContainerClient, __version__
import hashlib
import hmac
import base64
import time

app = Flask(__name__)


class User(object):

    def __init__(self, name, email, date, score):
        self.name = name
        self.email = email
        self.date = date
        self.score = score

    def __eq__(self, other):
        return self.name == other.name

    def __lt__(self, other):
        return int(self.score) < int(other.score)


def upload_file(upload_file_path, data):
    connect_str = "DefaultEndpointsProtocol=https;AccountName=xue;AccountKey=Xp5+gHw5N4e9mAhYFpNS8WNNbFJ/XfuhOlhSTGSLsOzySDlsIOoeucjdixRidL+1JX6NkEka9Umq4QVHka9xFg==;EndpointSuffix=core.windows.net"
    blob_service_client = BlobServiceClient.from_connection_string(connect_str)
    container_name = "ccc"
    container_client = blob_service_client.get_container_client(container_name)

    file = open(upload_file_path, 'w')
    file.write(data)
    file.close()

    # Upload the created file
    with open(upload_file_path, "rb") as data:
        container_client.upload_blob(upload_file_path, data, overwrite=True)


def list_files():
    connect_str = "DefaultEndpointsProtocol=https;AccountName=xue;AccountKey=Xp5+gHw5N4e9mAhYFpNS8WNNbFJ/XfuhOlhSTGSLsOzySDlsIOoeucjdixRidL+1JX6NkEka9Umq4QVHka9xFg==;EndpointSuffix=core.windows.net"
    blob_service_client = BlobServiceClient.from_connection_string(connect_str)
    container_name = "ccc"
    container_client = blob_service_client.get_container_client(container_name)

    blob_list = container_client.list_blobs()
    for blob in blob_list:
        print(blob.name)


def download_file(download_file_path):
    connect_str = "DefaultEndpointsProtocol=https;AccountName=xue;AccountKey=Xp5+gHw5N4e9mAhYFpNS8WNNbFJ/XfuhOlhSTGSLsOzySDlsIOoeucjdixRidL+1JX6NkEka9Umq4QVHka9xFg==;EndpointSuffix=core.windows.net"
    blob_service_client = BlobServiceClient.from_connection_string(connect_str)
    container_name = "ccc"
    container_client = blob_service_client.get_container_client(container_name)

    result = container_client.download_blob(
        download_file_path).readall().decode("utf-8")
    return result


@app.route("/")
def index():
    return "<h1>Welcome to chop-chop-chicken</h1>"


@app.route('/resetquestions', methods=['GET'])
def resetquestions():
    password = request.args.get("password")

    if password != "32r890h32rh8120rh":
        response = flask.jsonify("400 Bad Request")
        response.headers.add('Access-Control-Allow-Origin', '*')
        return response

    upload_file("questions.txt", "")
    result = "RESETTED QUESTIONS"
    response = flask.jsonify(result)
    response.headers.add('Access-Control-Allow-Origin', '*')
    return response


@app.route('/getquestions', methods=['GET'])
def getquestions():
    result = download_file("questions.txt")
    result = base64.b64encode(result.encode()).decode()
    response = flask.jsonify(result)
    response.headers.add('Access-Control-Allow-Origin', '*')

    return response


@app.route('/updatequestions', methods=['GET'])
def updatequestions():
    password = request.args.get("password")

    if password != "32r890h32rh8120rh":
        response = flask.jsonify("400 Bad Request")
        response.headers.add('Access-Control-Allow-Origin', '*')
        return response

    questions = request.args.get("questions")
    upload_file("questions.txt", questions)
    questions = base64.b64encode(questions.encode()).decode()
    response = flask.jsonify(questions)
    response.headers.add('Access-Control-Allow-Origin', '*')

    return response


@app.route('/resetprofile', methods=['GET'])
def resetprofile():
    password = request.args.get("password")
    print(password)

    if password != "32r890h32rh8120rh":
        response = flask.jsonify("400 Bad Request")
        response.headers.add('Access-Control-Allow-Origin', '*')
        return response

    upload_file("profile.txt", "")
    result = "RESETTED profile"
    response = flask.jsonify(result)
    response.headers.add('Access-Control-Allow-Origin', '*')
    return response


@app.route('/getprofile', methods=['GET'])
def getprofile():
    result = download_file("profile.txt")
    result = base64.b64encode(result.encode()).decode()
    response = flask.jsonify(result)
    response.headers.add('Access-Control-Allow-Origin', '*')

    return response


@app.route('/updateprofile', methods=['GET'])
def updateprofile():
    password = request.args.get("password")
    print(password)

    if password != "32r890h32rh8120rh":
        response = flask.jsonify("400 Bad Request")
        response.headers.add('Access-Control-Allow-Origin', '*')
        return response

    profile = request.args.get("profile")
    upload_file("profile.txt", profile)
    profile = base64.b64encode(profile.encode()).decode()
    response = flask.jsonify(profile)
    response.headers.add('Access-Control-Allow-Origin', '*')

    return response


@app.route('/resetfeedback', methods=['GET'])
def resetfeedback():
    password = request.args.get("password")

    if password != "32r890h32rh8120rh":
        response = flask.jsonify("400 Bad Request")
        response.headers.add('Access-Control-Allow-Origin', '*')
        return response

    upload_file("feedback.txt", "")
    result = "RESETTED FEEDBACK"
    response = flask.jsonify(result)
    response.headers.add('Access-Control-Allow-Origin', '*')
    return response


@app.route('/getfeedback', methods=['GET'])
def getfeedback():
    result = download_file("feedback.txt")
    result = base64.b64encode(result.encode()).decode()
    response = flask.jsonify(result)
    response.headers.add('Access-Control-Allow-Origin', '*')

    return response


@app.route('/updatefeedback', methods=['GET'])
def updatefeedback():
    newName = request.args.get("name")
    newEmail = request.args.get("email")
    newDate = datetime.now().strftime("%m/%d/%Y %H:%M:%S")
    newFeedback = request.args.get("feedback")
    text = download_file("feedback.txt")

    result = text + newName + "," + newEmail + \
        "," + newDate + "," + newFeedback + ";"
    upload_file("feedback.txt", result)

    result = base64.b64encode(result.encode()).decode()
    response = flask.jsonify(result)
    response.headers.add('Access-Control-Allow-Origin', '*')

    return response


@app.route('/resetusers', methods=['GET'])
def resetusers():
    password = request.args.get("password")

    if password != "32r890h32rh8120rh":
        response = flask.jsonify("400 Bad Request")
        response.headers.add('Access-Control-Allow-Origin', '*')
        return response

    upload_file("scores.txt", "")
    result = "RESETTED SCORES"
    response = flask.jsonify(result)
    response.headers.add('Access-Control-Allow-Origin', '*')

    return response


@app.route('/getusers', methods=['GET'])
def getusers():
    result = download_file("scores.txt")
    result = base64.b64encode(result.encode()).decode()
    response = flask.jsonify(result)
    response.headers.add('Access-Control-Allow-Origin', '*')

    return response


@app.route('/updateusers', methods=['GET'])
def updateusers():
    newName = request.args.get("name")
    newEmail = request.args.get("email")
    newDate = datetime.now().strftime("%m/%d/%Y %H:%M:%S")
    newScore = request.args.get("score")
    epoch = request.args.get("epoch")
    hmac = request.args.get("hmac")

    message = newName + ";" + newEmail + ";" + newScore + ";" + epoch
    calculated_hmac = encode(
        message, "u!1j^aSm5MdF9w@%peXcYY").decode("utf-8").replace("+", "-")
    calculated_epoch = get_epoch_time()

    if hmac != calculated_hmac:
        response = flask.jsonify("400 Bad Request")
        response.headers.add('Access-Control-Allow-Origin', '*')
        return response
    elif abs(calculated_epoch - int(epoch)) > 60:
        response = flask.jsonify("Is your system time set correctly?")
        response.headers.add('Access-Control-Allow-Origin', '*')
        return response

    userList = []
    result = ""

    text = download_file("scores.txt")

    foundUser = False
    if text == "":
        newUser = User(newName, newEmail, newDate, newScore)
        userList.append(newUser)
        foundUser = True
    else:
        users = text.split(";")
        for user in users:
            if user == "":
                break
            else:
                details = user.split(",")
                name = details[0]
                email = details[1]
                date = details[2]
                score = details[3]

                if name == newName:
                    foundUser = True
                    if (int(newScore) > int(score)):
                        newUser = User(newName, newEmail, newDate, newScore)
                        userList.append(newUser)
                    else:
                        newUser = User(name, email, date, score)
                        userList.append(newUser)
                else:
                    newUser = User(name, email, date, score)
                    userList.append(newUser)

    if not foundUser:
        newUser = User(newName, newEmail, newDate, newScore)
        userList.append(newUser)
        foundUser = True

    userList_sorted = sorted(userList)
    for user in userList_sorted:
        result += user.name + "," + user.email + \
            "," + user.date + "," + user.score + ";"

    if len(result) > 0:
        result = result[:-1]

    upload_file("scores.txt", result)

    result = base64.b64encode(result.encode()).decode()
    response = flask.jsonify(result)
    response.headers.add('Access-Control-Allow-Origin', '*')

    return response


def encode(message, secret):
    message = bytes(message, encoding='utf8')
    secret = bytes(secret, encoding='utf8')

    signature = base64.b64encode(
        hmac.new(secret, message, digestmod=hashlib.sha256).digest())
    return signature


def get_epoch_time():
    epoch_time = int(time.time())
    print(epoch_time)
    return epoch_time
